#!/bin/bash

curl http://192.168.0.50/test.txt -o t.txt